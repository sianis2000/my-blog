import Link from 'next/link';

export default function Home() {
  const posts = [
  { title: 'Αναζήτηση για εθελοντισμό', slug: 'volunteer-search', date: '20 Αυγούστου 2025' },
    { title: 'Καλωσόρισμα στο Blog μου!', slug: 'first-post', date: '19 Αυγούστου 2025' },
    { title: 'Σκέψεις για το Καλοκαίρι', slug: 'second-post', date: '15 Αυγούστου 2025' },
  ];

  return (
    <div className="max-w-3xl mx-auto p-6">
      <header className="text-center py-10">
        <h1 className="text-4xl font-bold mb-2">Το Προσωπικό μου Blog</h1>

        <p className="text-lg text-gray-600">Σκέψεις • Ιδέες • Εμπειρίες</p>
      </header>

      <main className="grid gap-6">
        {posts.map((post, index) => (
          <article key={index} className="bg-white rounded-2xl shadow-md p-6 hover:shadow-xl transition">
            <h2 className="text-2xl font-semibold mb-2">{post.title}</h2>
            <p className="text-sm text-gray-500 mb-4">{post.date}</p>
            <Link href={`/posts/${post.slug}`} className="text-blue-600 hover:underline">
              Διαβάστε περισσότερα
            </Link>
          </article>
        ))}
      </main>

      <footer className="text-center py-10 text-gray-500 text-sm">
        © 2025 Το Προσωπικό μου Blog — Φτιαγμένο με αγάπη 💙
      </footer>
    </div>
  );
}
