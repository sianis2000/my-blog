export default function SecondPost() {
  return (
    <div className="max-w-3xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">Σκέψεις για το Καλοκαίρι</h1>
      <p className="text-gray-600 mb-6">15 Αυγούστου 2025</p>
      <p>Το καλοκαίρι είναι πάντα μια περίοδος χαλάρωσης αλλά και έμπνευσης. Σε αυτό το άρθρο γράφω για τις εμπειρίες μου.</p>
    </div>
  );
}
